import React, { Component } from 'react';

class FooterComponent extends Component {
    render() {
        return (
            <div>
                <footer className="footer">Copyright by FINTECH CSI Pune @2022</footer>
            </div>
        );
    }
}

export default FooterComponent;