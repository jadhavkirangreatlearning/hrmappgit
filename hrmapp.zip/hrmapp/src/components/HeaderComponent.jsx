import React, { Component } from 'react';

class HeaderComponent extends Component {
    render() {
        return (
            <div>
               <header>
                    <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                    <div><a href="http://www.creditsystemsindia.com" className="navbar-brand">CREDIT SYSTEMS INDIA HRM Software</a></div>
                    </nav>
                </header>
            </div>
        );
    }
}

export default HeaderComponent;